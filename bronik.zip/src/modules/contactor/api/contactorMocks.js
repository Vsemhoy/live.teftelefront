export const CONTACT_GROUPS = [
  { value: 'all', label: 'All groups' },
  { value: 'family', label: 'Family' },
  { value: 'work', label: 'Work' },
  { value: 'friends', label: 'Friends' },
  { value: 'service', label: 'Services' },
];

export const LOG_TYPES = [
  { value: 'fact', label: 'Fact' },
  { value: 'meeting', label: 'Meeting' },
  { value: 'call', label: 'Call' },
  { value: 'note', label: 'Note' },
];

export const RELATION_KINDS = [
  { value: 'family', label: 'Family' },
  { value: 'friend', label: 'Friend' },
  { value: 'classmate', label: 'Classmate' },
  { value: 'coworker', label: 'Coworker' },
  { value: 'service', label: 'Service' },
];

export const MOCK_CONTACTS = [
  {
    id: 'cnt-1',
    name: 'Alex Morgan',
    group: 'work',
    role: 'Product lead',
    company: 'Northline Labs',
    avatar: '',
    last_contact_at: '2026-07-12T15:20:00',
    details: {
      phone: '+1 415 555 0182',
      telegram: '@alexmorgan',
      email: 'alex@northline.example',
      address: 'San Francisco, CA',
    },
  },
  {
    id: 'cnt-2',
    name: 'Maya Chen',
    group: 'friends',
    role: 'Designer',
    company: 'Freelance',
    avatar: '',
    last_contact_at: '2026-07-02T11:00:00',
    details: {
      phone: '+1 646 555 0144',
      telegram: '@mayasketch',
      email: 'maya@example.com',
      address: 'Brooklyn, NY',
    },
  },
  {
    id: 'cnt-3',
    name: 'Daniel Foster',
    group: 'service',
    role: 'Auto mechanic',
    company: 'Foster Garage',
    avatar: '',
    last_contact_at: '2026-06-18T09:30:00',
    details: {
      phone: '+1 312 555 0199',
      telegram: '',
      email: 'service@fostergarage.example',
      address: 'Chicago, IL',
    },
  },
  {
    id: 'cnt-4',
    name: 'Sofia Rivera',
    group: 'family',
    role: 'Sister',
    company: '',
    avatar: '',
    last_contact_at: '2026-07-14T20:15:00',
    details: {
      phone: '+1 213 555 0102',
      telegram: '@sofiar',
      email: 'sofia@example.com',
      address: 'Los Angeles, CA',
    },
  },
  {
    id: 'cnt-5',
    name: 'Nikolai Petrov',
    group: 'work',
    role: 'Backend engineer',
    company: 'Teftele',
    avatar: '',
    last_contact_at: '2026-06-30T17:45:00',
    details: {
      phone: '',
      telegram: '@nikpetrov',
      email: 'nikolai@teftele.example',
      address: '',
    },
  },
  {
    id: 'cnt-6',
    name: 'Emma Wilson',
    group: 'friends',
    role: 'University friend',
    company: '',
    avatar: '',
    last_contact_at: '2026-05-21T14:10:00',
    details: {
      phone: '+44 20 7946 0244',
      telegram: '@emwilson',
      email: 'emma@example.co.uk',
      address: 'London, UK',
    },
  },
];

export const MOCK_LOGS = [
  { id: 'log-1', contact_id: 'cnt-1', type: 'meeting', occurred_at: '2026-07-12T15:20:00', title: 'Roadmap sync', content: 'Discussed contact graph, import flow, and demo data strategy.', satellite_type: 'eventor', satellite_id: 'evt-120' },
  { id: 'log-2', contact_id: 'cnt-4', type: 'call', occurred_at: '2026-07-14T20:15:00', title: 'Family call', content: 'Quick check-in before the weekend.', satellite_type: null, satellite_id: null },
  { id: 'log-3', contact_id: 'cnt-2', type: 'note', occurred_at: '2026-07-02T11:00:00', title: 'Portfolio link', content: 'Sent the updated landing page references.', satellite_type: 'booker', satellite_id: 'doc-18' },
  { id: 'log-4', contact_id: 'cnt-5', type: 'meeting', occurred_at: '2026-06-30T17:45:00', title: 'Backend migration call', content: 'Agreed on namespacing and SQL export strategy.', satellite_type: 'eventor', satellite_id: 'evt-104' },
  { id: 'log-5', contact_id: 'cnt-3', type: 'fact', occurred_at: '2026-06-18T09:30:00', title: 'BMW service contact', content: 'Recommended for diesel diagnostics and suspension work.', satellite_type: 'exploiter', satellite_id: 'exp-21' },
  { id: 'log-6', contact_id: 'cnt-6', type: 'call', occurred_at: '2026-05-21T14:10:00', title: 'London trip advice', content: 'Shared a list of quiet cafes near Shoreditch.', satellite_type: null, satellite_id: null },
];

export const MOCK_RELATIONS = [
  { id: 'rel-1', from_contact_id: 'cnt-1', to_contact_id: 'cnt-5', kind: 'coworker', context: 'Teftele 2026', valid_from: '2026-01-01', valid_to: null },
  { id: 'rel-2', from_contact_id: 'cnt-2', to_contact_id: 'cnt-6', kind: 'classmate', context: 'Design school 2015', valid_from: '2015-09-01', valid_to: null },
  { id: 'rel-3', from_contact_id: 'cnt-1', to_contact_id: 'cnt-2', kind: 'friend', context: 'Product meetup', valid_from: '2024-04-12', valid_to: null },
  { id: 'rel-4', from_contact_id: 'cnt-4', to_contact_id: 'cnt-6', kind: 'friend', context: 'Travel group', valid_from: '2023-08-20', valid_to: '2025-12-31' },
];
