import { Badge, Box, Group, Stack, Text } from '@mantine/core';
import {
  IconCalendarEvent, IconLink, IconMessageCircle, IconNote, IconPhoneCall, IconSparkles,
} from '@tabler/icons-react';
import dayjs from 'dayjs';

const TYPE_META = {
  fact: { icon: IconSparkles, color: 'grape' },
  meeting: { icon: IconCalendarEvent, color: 'indigo' },
  call: { icon: IconPhoneCall, color: 'green' },
  note: { icon: IconNote, color: 'gray' },
};

export const LogEntry = ({ log, contact }) => {
  const meta = TYPE_META[log.type] || TYPE_META.note;
  const Icon = meta.icon;

  return (
    <Box className="cnt-log-entry">
      <Group align="flex-start" wrap="nowrap">
        <Box className={`cnt-log-icon ${meta.color}`}>
          <Icon size={15} />
        </Box>
        <Stack gap={3} style={{ minWidth: 0, flex: 1 }}>
          <Group gap={6} justify="space-between" wrap="nowrap">
            <Text size="sm" fw={650} truncate>{log.title || 'Untitled log entry'}</Text>
            <Text size="xs" c="dimmed" style={{ flexShrink: 0 }}>
              {dayjs(log.occurred_at).format('MMM D')}
            </Text>
          </Group>
          {contact && <Text size="xs" c="dimmed" truncate>{contact.name}</Text>}
          {log.content && <Text size="sm" c="gray.7">{log.content}</Text>}
          <Group gap={6}>
            <Badge size="xs" color={meta.color} variant="light">{log.type}</Badge>
            {log.satellite_type && (
              <Badge size="xs" variant="outline" color="gray" leftSection={<IconLink size={10} />}>
                {log.satellite_type}
              </Badge>
            )}
          </Group>
        </Stack>
      </Group>
    </Box>
  );
};
