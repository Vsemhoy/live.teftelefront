import { Box, Group, Stack, Text } from '@mantine/core';
import { IconAt, IconBrandTelegram, IconHome, IconPhone } from '@tabler/icons-react';

const ITEMS = [
  { key: 'phone', label: 'Phone', icon: IconPhone },
  { key: 'telegram', label: 'Telegram', icon: IconBrandTelegram },
  { key: 'email', label: 'Email', icon: IconAt },
  { key: 'address', label: 'Address', icon: IconHome },
];

export const DetailsSection = ({ details = {} }) => (
  <Box className="cnt-panel">
    <Text size="xs" fw={700} tt="uppercase" c="dimmed" mb={8}>Details</Text>
    <Stack gap={8}>
      {ITEMS.map(({ key, label, icon: Icon }) => (
        <Group key={key} gap={8} wrap="nowrap">
          <Icon size={15} color="var(--mantine-color-indigo-5)" />
          <Text size="xs" c="dimmed" w={74}>{label}</Text>
          <Text size="sm" style={{ overflowWrap: 'anywhere' }}>
            {details[key] || '—'}
          </Text>
        </Group>
      ))}
    </Stack>
  </Box>
);
