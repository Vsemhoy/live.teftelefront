import { Avatar, Badge, Card, Group, Stack, Text } from '@mantine/core';
import { IconMail, IconPhone, IconBrandTelegram } from '@tabler/icons-react';
import { useNavigate } from 'react-router-dom';
import { formatLastContact, getInitials } from '../../utils/contactorUtils';

export const ContactCard = ({ contact }) => {
  const navigate = useNavigate();
  const details = contact.details || {};

  return (
    <Card
      withBorder
      radius={8}
      p="sm"
      className="cnt-card"
      onClick={() => navigate(`/contactor/${contact.id}`)}
    >
      <Group align="flex-start" wrap="nowrap">
        <Avatar src={contact.avatar} radius="xl" color="indigo" size={42}>
          {getInitials(contact.name)}
        </Avatar>
        <Stack gap={3} style={{ minWidth: 0, flex: 1 }}>
          <Group justify="space-between" gap={6} wrap="nowrap">
            <Text size="sm" fw={700} truncate>{contact.name}</Text>
            <Badge size="xs" variant="light" color="indigo">{contact.group}</Badge>
          </Group>
          <Text size="xs" c="dimmed" truncate>
            {[contact.role, contact.company].filter(Boolean).join(' · ') || 'Contact'}
          </Text>
          <Text size="xs" c="indigo.7">{formatLastContact(contact.last_contact_at)}</Text>
          <Group gap={8} mt={4}>
            {details.phone && <IconPhone size={13} color="var(--mantine-color-gray-5)" />}
            {details.telegram && <IconBrandTelegram size={13} color="var(--mantine-color-gray-5)" />}
            {details.email && <IconMail size={13} color="var(--mantine-color-gray-5)" />}
          </Group>
        </Stack>
      </Group>
    </Card>
  );
};
