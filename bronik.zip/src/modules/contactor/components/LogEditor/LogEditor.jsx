import { useEffect, useState } from 'react';
import { Button, Group, Modal, Select, Stack, Textarea, TextInput } from '@mantine/core';
import { LOG_TYPES } from '../../api/contactorMocks';
import { useContactorStore } from '../../store/contactorStore';

const emptyForm = {
  contact_id: '',
  type: 'note',
  occurred_at: '',
  title: '',
  content: '',
  satellite_type: '',
  satellite_id: '',
};

export const LogEditor = () => {
  const {
    logEditorOpen, logEditorParams, closeLogEditor, contacts, saveLog,
  } = useContactorStore();
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (!logEditorOpen) return;
    setForm({
      ...emptyForm,
      contact_id: logEditorParams?.contact_id || contacts[0]?.id || '',
      occurred_at: new Date().toISOString().slice(0, 16),
    });
  }, [contacts, logEditorOpen, logEditorParams?.contact_id]);

  const patch = (key, value) => setForm((state) => ({ ...state, [key]: value }));

  const handleSave = () => {
    if (!form.contact_id || !form.title.trim()) return;
    saveLog({
      ...form,
      title: form.title.trim(),
      occurred_at: form.occurred_at ? new Date(form.occurred_at).toISOString() : new Date().toISOString(),
      satellite_type: form.satellite_type || null,
      satellite_id: form.satellite_id || null,
    });
  };

  return (
    <Modal opened={logEditorOpen} onClose={closeLogEditor} title="New log entry" size="lg">
      <Stack gap="sm">
        <Group grow align="flex-start">
          <Select
            label="Contact"
            value={form.contact_id}
            data={contacts.map((contact) => ({ value: contact.id, label: contact.name }))}
            onChange={(value) => patch('contact_id', value || '')}
          />
          <Select label="Type" value={form.type} data={LOG_TYPES} onChange={(value) => patch('type', value || 'note')} />
        </Group>
        <Group grow align="flex-start">
          <TextInput
            label="Time"
            type="datetime-local"
            value={form.occurred_at}
            onChange={(event) => patch('occurred_at', event.currentTarget.value)}
          />
          <TextInput label="Title" value={form.title} onChange={(event) => patch('title', event.currentTarget.value)} />
        </Group>
        <Textarea
          label="Content"
          minRows={4}
          value={form.content}
          onChange={(event) => patch('content', event.currentTarget.value)}
        />
        <Group grow align="flex-start">
          <TextInput label="Satellite type" value={form.satellite_type} onChange={(event) => patch('satellite_type', event.currentTarget.value)} />
          <TextInput label="Satellite id" value={form.satellite_id} onChange={(event) => patch('satellite_id', event.currentTarget.value)} />
        </Group>
        <Group justify="flex-end">
          <Button variant="subtle" color="gray" onClick={closeLogEditor}>Cancel</Button>
          <Button color="indigo" onClick={handleSave}>Save</Button>
        </Group>
      </Stack>
    </Modal>
  );
};
