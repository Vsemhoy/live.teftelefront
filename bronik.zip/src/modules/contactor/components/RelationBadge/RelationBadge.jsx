import { Badge } from '@mantine/core';

const COLORS = {
  family: 'pink',
  friend: 'green',
  classmate: 'blue',
  coworker: 'indigo',
  service: 'orange',
};

export const RelationBadge = ({ relation, contact }) => {
  const label = [
    relation.kind,
    contact?.name,
    relation.context,
  ].filter(Boolean).join(' · ');

  return (
    <Badge
      variant={relation.valid_to ? 'outline' : 'light'}
      color={COLORS[relation.kind] || 'gray'}
      radius="sm"
      styles={{ label: { textTransform: 'none' } }}
    >
      {label}
    </Badge>
  );
};
