import { useEffect, useState } from 'react';
import { Button, Group, Modal, Select, Stack, TextInput } from '@mantine/core';
import { RELATION_KINDS } from '../../api/contactorMocks';
import { useContactorStore } from '../../store/contactorStore';

const emptyForm = {
  from_contact_id: '',
  to_contact_id: '',
  kind: 'friend',
  context: '',
  valid_from: '',
  valid_to: '',
};

export const RelationEditor = () => {
  const {
    relationEditorOpen, relationEditorParams, closeRelationEditor, contacts, saveRelation,
  } = useContactorStore();
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (!relationEditorOpen) return;
    const from = relationEditorParams?.contact_id || contacts[0]?.id || '';
    const to = contacts.find((contact) => contact.id !== from)?.id || '';
    setForm({ ...emptyForm, from_contact_id: from, to_contact_id: to });
  }, [contacts, relationEditorOpen, relationEditorParams?.contact_id]);

  const patch = (key, value) => setForm((state) => ({ ...state, [key]: value }));

  const contactOptions = contacts.map((contact) => ({ value: contact.id, label: contact.name }));

  const handleSave = () => {
    if (!form.from_contact_id || !form.to_contact_id || form.from_contact_id === form.to_contact_id) return;
    saveRelation({
      ...form,
      valid_from: form.valid_from || null,
      valid_to: form.valid_to || null,
    });
  };

  return (
    <Modal opened={relationEditorOpen} onClose={closeRelationEditor} title="New relation" size="lg">
      <Stack gap="sm">
        <Group grow align="flex-start">
          <Select label="From" value={form.from_contact_id} data={contactOptions} onChange={(value) => patch('from_contact_id', value || '')} />
          <Select label="To" value={form.to_contact_id} data={contactOptions} onChange={(value) => patch('to_contact_id', value || '')} />
        </Group>
        <Group grow align="flex-start">
          <Select label="Kind" value={form.kind} data={RELATION_KINDS} onChange={(value) => patch('kind', value || 'friend')} />
          <TextInput label="Context" value={form.context} onChange={(event) => patch('context', event.currentTarget.value)} />
        </Group>
        <Group grow align="flex-start">
          <TextInput label="Valid from" type="date" value={form.valid_from} onChange={(event) => patch('valid_from', event.currentTarget.value)} />
          <TextInput label="Valid to" type="date" value={form.valid_to} onChange={(event) => patch('valid_to', event.currentTarget.value)} />
        </Group>
        <Group justify="flex-end">
          <Button variant="subtle" color="gray" onClick={closeRelationEditor}>Cancel</Button>
          <Button color="indigo" onClick={handleSave}>Save</Button>
        </Group>
      </Stack>
    </Modal>
  );
};
