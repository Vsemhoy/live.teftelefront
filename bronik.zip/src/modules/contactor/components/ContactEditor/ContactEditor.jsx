import { useEffect, useMemo, useState } from 'react';
import { Button, Group, Modal, Select, SimpleGrid, Stack, TextInput } from '@mantine/core';
import { CONTACT_GROUPS } from '../../api/contactorMocks';
import { useContactorStore } from '../../store/contactorStore';

const emptyForm = {
  name: '',
  group: 'friends',
  role: '',
  company: '',
  last_contact_at: '',
  details: {
    phone: '',
    telegram: '',
    email: '',
    address: '',
  },
};

export const ContactEditor = () => {
  const {
    contactEditorOpen, contactEditorParams, closeContactEditor, contacts, saveContact,
  } = useContactorStore();
  const [form, setForm] = useState(emptyForm);

  const editing = useMemo(
    () => contacts.find((contact) => contact.id === contactEditorParams?.id),
    [contacts, contactEditorParams?.id]
  );

  useEffect(() => {
    if (!contactEditorOpen) return;
    setForm(editing ? {
      ...emptyForm,
      ...editing,
      details: { ...emptyForm.details, ...(editing.details || {}) },
      last_contact_at: editing.last_contact_at ? editing.last_contact_at.slice(0, 16) : '',
    } : emptyForm);
  }, [contactEditorOpen, editing]);

  const patch = (key, value) => setForm((state) => ({ ...state, [key]: value }));
  const patchDetail = (key, value) => setForm((state) => ({
    ...state,
    details: { ...state.details, [key]: value },
  }));

  const handleSave = () => {
    const name = form.name.trim();
    if (!name) return;

    saveContact({
      ...form,
      id: editing?.id,
      name,
      last_contact_at: form.last_contact_at ? new Date(form.last_contact_at).toISOString() : null,
    });
  };

  return (
    <Modal opened={contactEditorOpen} onClose={closeContactEditor} title={editing ? 'Edit contact' : 'New contact'} size="lg">
      <Stack gap="sm">
        <SimpleGrid cols={{ base: 1, sm: 2 }}>
          <TextInput label="Name" value={form.name} onChange={(event) => patch('name', event.currentTarget.value)} />
          <Select
            label="Group"
            value={form.group}
            data={CONTACT_GROUPS.filter((group) => group.value !== 'all')}
            onChange={(value) => patch('group', value || 'friends')}
          />
          <TextInput label="Role" value={form.role} onChange={(event) => patch('role', event.currentTarget.value)} />
          <TextInput label="Company" value={form.company} onChange={(event) => patch('company', event.currentTarget.value)} />
          <TextInput
            label="Last contact"
            type="datetime-local"
            value={form.last_contact_at}
            onChange={(event) => patch('last_contact_at', event.currentTarget.value)}
          />
        </SimpleGrid>

        <SimpleGrid cols={{ base: 1, sm: 2 }}>
          <TextInput label="Phone" value={form.details.phone} onChange={(event) => patchDetail('phone', event.currentTarget.value)} />
          <TextInput label="Telegram" value={form.details.telegram} onChange={(event) => patchDetail('telegram', event.currentTarget.value)} />
          <TextInput label="Email" value={form.details.email} onChange={(event) => patchDetail('email', event.currentTarget.value)} />
          <TextInput label="Address" value={form.details.address} onChange={(event) => patchDetail('address', event.currentTarget.value)} />
        </SimpleGrid>

        <Group justify="flex-end">
          <Button variant="subtle" color="gray" onClick={closeContactEditor}>Cancel</Button>
          <Button color="indigo" onClick={handleSave}>Save</Button>
        </Group>
      </Stack>
    </Modal>
  );
};
