import dayjs from 'dayjs';

export const formatLastContact = (value) => {
  if (!value) return 'Never contacted';

  const date = dayjs(value);
  const days = dayjs().diff(date, 'day');

  if (days <= 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 30) return `${days} days ago`;
  return date.format('MMM D, YYYY');
};

export const buildRelationGraph = (contacts = [], relations = []) => {
  const nodes = contacts.map((contact) => ({
    id: contact.id,
    label: contact.name,
    group: contact.group,
  }));

  const links = relations.map((relation) => ({
    id: relation.id,
    source: relation.from_contact_id,
    target: relation.to_contact_id,
    kind: relation.kind,
    expired: Boolean(relation.valid_to),
    context: relation.context,
  }));

  return { nodes, links };
};

export const getInitials = (name = '') =>
  name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || '?';

export const contactMatches = (contact, query) => {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;

  return [
    contact.name,
    contact.group,
    contact.role,
    contact.company,
    contact.details?.phone,
    contact.details?.telegram,
    contact.details?.email,
  ].some((value) => String(value || '').toLowerCase().includes(needle));
};
