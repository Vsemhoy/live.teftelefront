import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { MOCK_CONTACTS, MOCK_LOGS, MOCK_RELATIONS } from '../api/contactorMocks';

const makeId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

export const useContactorStore = create(
  persist(
    (set, get) => ({
      contacts: MOCK_CONTACTS,
      logs: MOCK_LOGS,
      relations: MOCK_RELATIONS,

      groupFilter: 'all',
      searchQuery: '',
      setGroupFilter: (value) => set({ groupFilter: value }),
      setSearchQuery: (value) => set({ searchQuery: value }),

      contactEditorOpen: false,
      contactEditorParams: null,
      openContactEditor: (params = {}) => set({ contactEditorOpen: true, contactEditorParams: params }),
      closeContactEditor: () => set({ contactEditorOpen: false, contactEditorParams: null }),

      logEditorOpen: false,
      logEditorParams: null,
      openLogEditor: (params = {}) => set({ logEditorOpen: true, logEditorParams: params }),
      closeLogEditor: () => set({ logEditorOpen: false, logEditorParams: null }),

      relationEditorOpen: false,
      relationEditorParams: null,
      openRelationEditor: (params = {}) => set({ relationEditorOpen: true, relationEditorParams: params }),
      closeRelationEditor: () => set({ relationEditorOpen: false, relationEditorParams: null }),

      saveContact: (payload) => {
        const contacts = get().contacts;
        const next = {
          ...payload,
          id: payload.id || makeId('cnt'),
          details: payload.details || {},
          last_contact_at: payload.last_contact_at || null,
        };

        set({
          contacts: contacts.some((contact) => contact.id === next.id)
            ? contacts.map((contact) => (contact.id === next.id ? { ...contact, ...next } : contact))
            : [next, ...contacts],
          contactEditorOpen: false,
          contactEditorParams: null,
        });

        return next;
      },

      saveLog: (payload) => {
        const logs = get().logs;
        const next = {
          ...payload,
          id: payload.id || makeId('log'),
          occurred_at: payload.occurred_at || new Date().toISOString(),
        };

        set({
          logs: logs.some((log) => log.id === next.id)
            ? logs.map((log) => (log.id === next.id ? { ...log, ...next } : log))
            : [next, ...logs],
          contacts: get().contacts.map((contact) => (
            contact.id === next.contact_id
              ? { ...contact, last_contact_at: next.occurred_at }
              : contact
          )),
          logEditorOpen: false,
          logEditorParams: null,
        });

        return next;
      },

      saveRelation: (payload) => {
        const relations = get().relations;
        const next = {
          ...payload,
          id: payload.id || makeId('rel'),
        };

        set({
          relations: relations.some((relation) => relation.id === next.id)
            ? relations.map((relation) => (relation.id === next.id ? { ...relation, ...next } : relation))
            : [next, ...relations],
          relationEditorOpen: false,
          relationEditorParams: null,
        });

        return next;
      },
    }),
    {
      name: 'contactor-ui',
      partialize: (state) => ({
        contacts: state.contacts,
        logs: state.logs,
        relations: state.relations,
        groupFilter: state.groupFilter,
        searchQuery: state.searchQuery,
      }),
    }
  )
);
