// БД иконок: slug → теги для поиска
// Добавить иконку: закинуть SVG в public/icons/, добавить строку сюда
export const ICONS_DB = [
  {
    "slug": "adjustable_wrench",
    "tags": [
      "инструменты",
      "ремонт"
    ]
  },
  {
    "slug": "air_ball",
    "tags": [
      "спорт",
      "развлечения"
    ]
  },
  {
    "slug": "alladin_lamp",
    "tags": [
      "фантастика",
      "магия"
    ]
  },
  {
    "slug": "array_cube",
    "tags": [
      "разработка",
      "программирование"
    ]
  },
  {
    "slug": "arrow_camera",
    "tags": [
      "фото"
    ]
  },
  {
    "slug": "arrow_crossed",
    "tags": [
      "навигация",
      "интерфейс"
    ]
  },
  {
    "slug": "arrow_infinity",
    "tags": [
      "интерфейс",
      "петля"
    ]
  },
  {
    "slug": "arrow_rolled",
    "tags": [
      "интерфейс",
      "навигация"
    ]
  },
  {
    "slug": "arrow_spring",
    "tags": [
      "интерфейс"
    ]
  },
  {
    "slug": "arrow_two_way",
    "tags": [
      "интерфейс",
      "навигация"
    ]
  },
  {
    "slug": "arrows_rolled",
    "tags": [
      "интерфейс",
      "навигация"
    ]
  },
  {
    "slug": "atom_links",
    "tags": [
      "наука"
    ]
  },
  {
    "slug": "attention_sign",
    "tags": [
      "предупреждение"
    ]
  },
  {
    "slug": "baby_todler",
    "tags": [
      "люди",
      "дети"
    ]
  },
  {
    "slug": "bag_case",
    "tags": [
      "шоппинг",
      "сумка"
    ]
  },
  {
    "slug": "bag_shopping",
    "tags": [
      "шоппинг",
      "сумка"
    ]
  },
  {
    "slug": "bag_travel",
    "tags": [
      "шоппинг",
      "сумка",
      "путешествия"
    ]
  },
  {
    "slug": "bar_code",
    "tags": [
      "шоппинг",
      "сканер"
    ]
  },
  {
    "slug": "beer_mug",
    "tags": [
      "еда",
      "напитки",
      "алкоголь"
    ]
  },
  {
    "slug": "bended_sheet",
    "tags": [
      "документы",
      "бумага"
    ]
  },
  {
    "slug": "billiard_ball",
    "tags": [
      "развлечения",
      "спорт"
    ]
  },
  {
    "slug": "bird_pigeon",
    "tags": [
      "природа"
    ]
  },
  {
    "slug": "bone",
    "tags": [
      "питомцы"
    ]
  },
  {
    "slug": "boo_mask",
    "tags": [
      "хэллоуин"
    ]
  },
  {
    "slug": "book_papered",
    "tags": [
      "образование",
      "документы",
      "хэллоуин"
    ]
  },
  {
    "slug": "bookmark_down",
    "tags": [
      "образование",
      "документы",
      "хэллоуин"
    ]
  },
  {
    "slug": "bow_tie",
    "tags": [
      "одежда",
      "стиль"
    ]
  },
  {
    "slug": "bow_with_arrows",
    "tags": [
      "спорт",
      "охота"
    ]
  },
  {
    "slug": "bulb_lamp",
    "tags": [
      "идея",
      "свет"
    ]
  },
  {
    "slug": "bus_stop",
    "tags": [
      "транспорт",
      "автобус"
    ]
  },
  {
    "slug": "butterfly_simple",
    "tags": [
      "природа"
    ]
  },
  {
    "slug": "bycycle",
    "tags": [
      "транспорт",
      "велосипед"
    ]
  },
  {
    "slug": "calendar_list",
    "tags": [
      "время",
      "планирование"
    ]
  },
  {
    "slug": "camera_arrow",
    "tags": [
      "фото"
    ]
  },
  {
    "slug": "car_jeep",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "card_arrow_down",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "card_bookmark",
    "tags": [
      "авто",
      "транспорт",
      "образование",
      "документы",
      "хэллоуин"
    ]
  },
  {
    "slug": "card_game_clubs",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "card_game_diamonds",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "card_game_hearts",
    "tags": [
      "авто",
      "транспорт",
      "избранное",
      "любовь"
    ]
  },
  {
    "slug": "card_game_spades",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "cargo_truck",
    "tags": [
      "авто",
      "транспорт",
      "грузовик"
    ]
  },
  {
    "slug": "chart_bars",
    "tags": [
      "статистика",
      "аналитика"
    ]
  },
  {
    "slug": "chart_graphic",
    "tags": [
      "статистика",
      "аналитика"
    ]
  },
  {
    "slug": "chat_empty",
    "tags": [
      "общение"
    ]
  },
  {
    "slug": "chat_filled",
    "tags": [
      "общение"
    ]
  },
  {
    "slug": "chat_zzz",
    "tags": [
      "общение"
    ]
  },
  {
    "slug": "checkbox_checked",
    "tags": [
      "задачи",
      "интерфейс"
    ]
  },
  {
    "slug": "chemical_flask",
    "tags": [
      "наука"
    ]
  },
  {
    "slug": "chemical_tube",
    "tags": [
      "наука"
    ]
  },
  {
    "slug": "chicken_leg",
    "tags": [
      "еда",
      "мясо"
    ]
  },
  {
    "slug": "city_building",
    "tags": [
      "город",
      "недвижимость"
    ]
  },
  {
    "slug": "city_bus",
    "tags": [
      "транспорт",
      "автобус",
      "город"
    ]
  },
  {
    "slug": "clock_round",
    "tags": [
      "безопасность"
    ]
  },
  {
    "slug": "clothes_hanger",
    "tags": [
      "одежда",
      "шоппинг"
    ]
  },
  {
    "slug": "cloud_in_arrow",
    "tags": [
      "погода"
    ]
  },
  {
    "slug": "cloud_thunder",
    "tags": [
      "погода"
    ]
  },
  {
    "slug": "coffee_cup",
    "tags": [
      "еда",
      "напитки"
    ]
  },
  {
    "slug": "coffer_arrowin",
    "tags": [
      "финансы"
    ]
  },
  {
    "slug": "coffer_docs",
    "tags": [
      "финансы"
    ]
  },
  {
    "slug": "cog_double",
    "tags": [
      "инструменты",
      "настройки"
    ]
  },
  {
    "slug": "cog_single",
    "tags": [
      "инструменты",
      "настройки"
    ]
  },
  {
    "slug": "console_joystick",
    "tags": [
      "развлечения",
      "игры"
    ]
  },
  {
    "slug": "credit_card",
    "tags": [
      "авто",
      "транспорт",
      "финансы",
      "карта"
    ]
  },
  {
    "slug": "cup_hot",
    "tags": [
      "еда",
      "напитки"
    ]
  },
  {
    "slug": "dice",
    "tags": [
      "развлечения",
      "игры"
    ]
  },
  {
    "slug": "document_schredder",
    "tags": [
      "документы"
    ]
  },
  {
    "slug": "dog_house",
    "tags": [
      "дом",
      "недвижимость"
    ]
  },
  {
    "slug": "draw_pencil",
    "tags": [
      "творчество"
    ]
  },
  {
    "slug": "dress_sock",
    "tags": [
      "одежда",
      "шоппинг"
    ]
  },
  {
    "slug": "dress_tshirt",
    "tags": [
      "одежда",
      "шоппинг"
    ]
  },
  {
    "slug": "dumbell",
    "tags": [
      "спорт",
      "фитнес"
    ]
  },
  {
    "slug": "eating_cup",
    "tags": [
      "еда",
      "напитки"
    ]
  },
  {
    "slug": "eye_opened",
    "tags": [
      "интерфейс",
      "просмотр"
    ]
  },
  {
    "slug": "faders",
    "tags": [
      "настройки",
      "музыка"
    ]
  },
  {
    "slug": "farm_tractor",
    "tags": [
      "сельское хозяйство",
      "транспорт"
    ]
  },
  {
    "slug": "file_cabinet",
    "tags": [
      "документы"
    ]
  },
  {
    "slug": "film_babine",
    "tags": [
      "развлечения",
      "кино"
    ]
  },
  {
    "slug": "film_cassete",
    "tags": [
      "развлечения",
      "кино"
    ]
  },
  {
    "slug": "film_doublecut",
    "tags": [
      "развлечения",
      "кино"
    ]
  },
  {
    "slug": "film_triple_cut",
    "tags": [
      "развлечения",
      "кино"
    ]
  },
  {
    "slug": "film_tub",
    "tags": [
      "развлечения",
      "кино"
    ]
  },
  {
    "slug": "fire_extinguisher",
    "tags": [
      "аварийное"
    ]
  },
  {
    "slug": "flag_down",
    "tags": [
      "навигация",
      "цель"
    ]
  },
  {
    "slug": "flask_bulb",
    "tags": [
      "наука"
    ]
  },
  {
    "slug": "flyer_double",
    "tags": [
      "документы",
      "реклама"
    ]
  },
  {
    "slug": "flyer_single",
    "tags": [
      "документы",
      "реклама"
    ]
  },
  {
    "slug": "fork_knife",
    "tags": [
      "еда"
    ]
  },
  {
    "slug": "fortress_tower",
    "tags": [
      "история",
      "строение"
    ]
  },
  {
    "slug": "four_leaf_clover",
    "tags": [
      "природа",
      "удача"
    ]
  },
  {
    "slug": "furniture_nightstand",
    "tags": [
      "дом",
      "мебель"
    ]
  },
  {
    "slug": "gas_station",
    "tags": [
      "авто",
      "заправка"
    ]
  },
  {
    "slug": "gift_box",
    "tags": [
      "праздник",
      "подарки"
    ]
  },
  {
    "slug": "glasses_closed",
    "tags": [
      "стиль",
      "аксессуары"
    ]
  },
  {
    "slug": "glasses_rounded",
    "tags": [
      "стиль",
      "аксессуары"
    ]
  },
  {
    "slug": "glasses_square",
    "tags": [
      "стиль",
      "аксессуары"
    ]
  },
  {
    "slug": "goblet_pot",
    "tags": [
      "еда",
      "напитки"
    ]
  },
  {
    "slug": "golf_flag",
    "tags": [
      "спорт"
    ]
  },
  {
    "slug": "grocery_cart",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "hammer_mallet",
    "tags": [
      "инструменты",
      "ремонт"
    ]
  },
  {
    "slug": "hammer_tool",
    "tags": [
      "инструменты",
      "ремонт"
    ]
  },
  {
    "slug": "headphones",
    "tags": [
      "связь",
      "гаджеты",
      "музыка"
    ]
  },
  {
    "slug": "heartbeat_sinus",
    "tags": [
      "здоровье",
      "избранное",
      "любовь"
    ]
  },
  {
    "slug": "horn_speaker",
    "tags": [
      "звук",
      "музыка"
    ]
  },
  {
    "slug": "house_door",
    "tags": [
      "дом",
      "недвижимость"
    ]
  },
  {
    "slug": "house_onwheel",
    "tags": [
      "дом",
      "недвижимость"
    ]
  },
  {
    "slug": "house_wooden",
    "tags": [
      "дом",
      "недвижимость"
    ]
  },
  {
    "slug": "human_group",
    "tags": [
      "люди",
      "группа"
    ]
  },
  {
    "slug": "ice_cream",
    "tags": [
      "еда",
      "десерт"
    ]
  },
  {
    "slug": "insect_bug",
    "tags": [
      "природа",
      "насекомые"
    ]
  },
  {
    "slug": "invalid_man",
    "tags": [
      "люди",
      "здоровье"
    ]
  },
  {
    "slug": "ipod_player",
    "tags": [
      "гаджеты",
      "музыка"
    ]
  },
  {
    "slug": "jasons_mask",
    "tags": [
      "хэллоуин"
    ]
  },
  {
    "slug": "jeep_car",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "key_single",
    "tags": [
      "безопасность"
    ]
  },
  {
    "slug": "knot_on_finger",
    "tags": [
      "напоминание",
      "заметки"
    ]
  },
  {
    "slug": "laptop_mac",
    "tags": [
      "гаджеты",
      "работа"
    ]
  },
  {
    "slug": "lifebuoy",
    "tags": [
      "безопасность",
      "море"
    ]
  },
  {
    "slug": "location_arrow",
    "tags": [
      "навигация"
    ]
  },
  {
    "slug": "lock_locked",
    "tags": [
      "безопасность"
    ]
  },
  {
    "slug": "mail_letter",
    "tags": [
      "общение"
    ]
  },
  {
    "slug": "man_running_single",
    "tags": [
      "люди"
    ]
  },
  {
    "slug": "man_stands",
    "tags": [
      "люди"
    ]
  },
  {
    "slug": "man_walking",
    "tags": [
      "люди"
    ]
  },
  {
    "slug": "map_mark",
    "tags": [
      "навигация",
      "путешествия"
    ]
  },
  {
    "slug": "map_path",
    "tags": [
      "навигация",
      "путешествия"
    ]
  },
  {
    "slug": "map_pin",
    "tags": [
      "навигация",
      "путешествия"
    ]
  },
  {
    "slug": "meal_fastfood",
    "tags": [
      "еда",
      "фастфуд"
    ]
  },
  {
    "slug": "medal_star",
    "tags": [
      "спорт",
      "награда"
    ]
  },
  {
    "slug": "medical_case",
    "tags": [
      "здоровье",
      "медицина"
    ]
  },
  {
    "slug": "medical_patch",
    "tags": [
      "здоровье",
      "медицина"
    ]
  },
  {
    "slug": "medical_plus",
    "tags": [
      "здоровье",
      "медицина"
    ]
  },
  {
    "slug": "microphone_ontable",
    "tags": [
      "связь",
      "гаджеты"
    ]
  },
  {
    "slug": "mill_house",
    "tags": [
      "дом",
      "недвижимость"
    ]
  },
  {
    "slug": "mixer_faders",
    "tags": [
      "настройки",
      "музыка"
    ]
  },
  {
    "slug": "moon_half",
    "tags": [
      "природа",
      "погода"
    ]
  },
  {
    "slug": "municipal_building",
    "tags": [
      "город",
      "недвижимость"
    ]
  },
  {
    "slug": "music_note",
    "tags": [
      "музыка"
    ]
  },
  {
    "slug": "newspapers",
    "tags": [
      "новости",
      "документы"
    ]
  },
  {
    "slug": "newspapers_top",
    "tags": [
      "новости",
      "документы"
    ]
  },
  {
    "slug": "note_page",
    "tags": [
      "документы",
      "заметки"
    ]
  },
  {
    "slug": "paint_roller",
    "tags": [
      "творчество",
      "ремонт"
    ]
  },
  {
    "slug": "palette",
    "tags": [
      "творчество"
    ]
  },
  {
    "slug": "paperclip",
    "tags": [
      "документы",
      "вложения"
    ]
  },
  {
    "slug": "passenger_car",
    "tags": [
      "авто",
      "транспорт"
    ]
  },
  {
    "slug": "path_navigation",
    "tags": [
      "навигация",
      "маршрут"
    ]
  },
  {
    "slug": "paw_print",
    "tags": [
      "питомцы"
    ]
  },
  {
    "slug": "pc_display",
    "tags": [
      "гаджеты",
      "работа"
    ]
  },
  {
    "slug": "pc_display2",
    "tags": [
      "гаджеты",
      "работа"
    ]
  },
  {
    "slug": "pc_display_wide",
    "tags": [
      "гаджеты",
      "работа"
    ]
  },
  {
    "slug": "phone_handset",
    "tags": [
      "связь",
      "гаджеты"
    ]
  },
  {
    "slug": "phone_smart",
    "tags": [
      "связь",
      "гаджеты"
    ]
  },
  {
    "slug": "photo_camera",
    "tags": [
      "фото"
    ]
  },
  {
    "slug": "piano_keys",
    "tags": [
      "музыка",
      "безопасность"
    ]
  },
  {
    "slug": "picture_hanged",
    "tags": [
      "творчество",
      "интерьер"
    ]
  },
  {
    "slug": "piggy_bank",
    "tags": [
      "финансы",
      "копилка"
    ]
  },
  {
    "slug": "pill_capsule",
    "tags": [
      "здоровье",
      "медицина"
    ]
  },
  {
    "slug": "pipette",
    "tags": [
      "творчество",
      "наука"
    ]
  },
  {
    "slug": "plane_flight",
    "tags": [
      "транспорт",
      "авиа"
    ]
  },
  {
    "slug": "planet_jupiter",
    "tags": [
      "транспорт",
      "авиа",
      "космос"
    ]
  },
  {
    "slug": "police_badge",
    "tags": [
      "безопасность"
    ]
  },
  {
    "slug": "price_tag_shortcut",
    "tags": [
      "финансы",
      "цена"
    ]
  },
  {
    "slug": "puzzle_chunk",
    "tags": [
      "игры",
      "интеграция"
    ]
  },
  {
    "slug": "radiation_sign",
    "tags": [
      "предупреждение"
    ]
  },
  {
    "slug": "rechargeble_battery",
    "tags": [
      "гаджеты",
      "энергия"
    ]
  },
  {
    "slug": "roadsign_arrow",
    "tags": [
      "навигация",
      "транспорт"
    ]
  },
  {
    "slug": "round_blacknwhite",
    "tags": [
      "интерфейс"
    ]
  },
  {
    "slug": "round_compas",
    "tags": [
      "навигация",
      "путешествия"
    ]
  },
  {
    "slug": "rss_sign",
    "tags": [
      "интернет",
      "новости"
    ]
  },
  {
    "slug": "sailboat",
    "tags": [
      "путешествия",
      "море"
    ]
  },
  {
    "slug": "schamrock_plant",
    "tags": [
      "природа"
    ]
  },
  {
    "slug": "scheme_path",
    "tags": [
      "разработка",
      "планирование"
    ]
  },
  {
    "slug": "school_lule",
    "tags": [
      "образование"
    ]
  },
  {
    "slug": "sealed_flask",
    "tags": [
      "наука"
    ]
  },
  {
    "slug": "search_lens",
    "tags": [
      "поиск"
    ]
  },
  {
    "slug": "sega_joystick",
    "tags": [
      "развлечения",
      "игры"
    ]
  },
  {
    "slug": "shape_heart",
    "tags": [
      "избранное",
      "любовь"
    ]
  },
  {
    "slug": "shape_star",
    "tags": [
      "избранное"
    ]
  },
  {
    "slug": "ship_anchor",
    "tags": [
      "транспорт",
      "море"
    ]
  },
  {
    "slug": "shoots_polaroid",
    "tags": [
      "фото",
      "воспоминания"
    ]
  },
  {
    "slug": "shot_glass",
    "tags": [
      "еда",
      "напитки",
      "алкоголь"
    ]
  },
  {
    "slug": "simple_calculator",
    "tags": [
      "финансы",
      "математика"
    ]
  },
  {
    "slug": "skull_bones",
    "tags": [
      "питомцы",
      "хэллоуин"
    ]
  },
  {
    "slug": "skull_only",
    "tags": [
      "хэллоуин"
    ]
  },
  {
    "slug": "socket_outlet",
    "tags": [
      "дом",
      "электричество"
    ]
  },
  {
    "slug": "sound_note",
    "tags": [
      "музыка",
      "звук"
    ]
  },
  {
    "slug": "speedometer",
    "tags": [
      "статистика"
    ]
  },
  {
    "slug": "square_item_material",
    "tags": [
      "интерфейс"
    ]
  },
  {
    "slug": "square_language_c",
    "tags": [
      "разработка",
      "программирование"
    ]
  },
  {
    "slug": "square_language_cpp",
    "tags": [
      "разработка",
      "программирование"
    ]
  },
  {
    "slug": "square_language_csharp",
    "tags": [
      "разработка",
      "программирование"
    ]
  },
  {
    "slug": "square_language_html",
    "tags": [
      "разработка",
      "веб"
    ]
  },
  {
    "slug": "square_language_javascript",
    "tags": [
      "разработка",
      "веб"
    ]
  },
  {
    "slug": "square_language_math",
    "tags": [
      "образование",
      "математика"
    ]
  },
  {
    "slug": "square_language_php",
    "tags": [
      "разработка",
      "веб"
    ]
  },
  {
    "slug": "square_program_illustrator",
    "tags": [
      "творчество",
      "дизайн"
    ]
  },
  {
    "slug": "square_program_photoshop",
    "tags": [
      "фото",
      "творчество",
      "дизайн"
    ]
  },
  {
    "slug": "square_program_word",
    "tags": [
      "документы",
      "офис"
    ]
  },
  {
    "slug": "statue_liberty",
    "tags": [
      "путешествия",
      "история"
    ]
  },
  {
    "slug": "stopwatch",
    "tags": [
      "время",
      "спорт"
    ]
  },
  {
    "slug": "sun_dni",
    "tags": [
      "природа",
      "погода"
    ]
  },
  {
    "slug": "sun_star",
    "tags": [
      "природа",
      "погода"
    ]
  },
  {
    "slug": "tablet_pc",
    "tags": [
      "гаджеты",
      "работа"
    ]
  },
  {
    "slug": "tag_man_mark",
    "tags": [
      "люди"
    ]
  },
  {
    "slug": "tall_buildings",
    "tags": [
      "город",
      "недвижимость"
    ]
  },
  {
    "slug": "target_aim",
    "tags": [
      "спорт",
      "цель"
    ]
  },
  {
    "slug": "target_darts",
    "tags": [
      "спорт",
      "цель"
    ]
  },
  {
    "slug": "target_darts_goal",
    "tags": [
      "спорт",
      "цель"
    ]
  },
  {
    "slug": "telescope",
    "tags": [
      "наука",
      "космос"
    ]
  },
  {
    "slug": "thunder",
    "tags": [
      "погода"
    ]
  },
  {
    "slug": "ticket",
    "tags": [
      "развлечения",
      "транспорт"
    ]
  },
  {
    "slug": "tie_dress",
    "tags": [
      "одежда",
      "стиль"
    ]
  },
  {
    "slug": "tm_telegram_messanger",
    "tags": [
      "общение"
    ]
  },
  {
    "slug": "tree_fir",
    "tags": [
      "природа"
    ]
  },
  {
    "slug": "tv_set",
    "tags": [
      "развлечения"
    ]
  },
  {
    "slug": "ufo",
    "tags": [
      "фантастика"
    ]
  },
  {
    "slug": "ufo_mask",
    "tags": [
      "фантастика"
    ]
  },
  {
    "slug": "ukulele_guitar",
    "tags": [
      "музыка",
      "инструменты"
    ]
  },
  {
    "slug": "umbrella",
    "tags": [
      "погода"
    ]
  },
  {
    "slug": "user_card",
    "tags": [
      "авто",
      "транспорт",
      "люди"
    ]
  },
  {
    "slug": "viking_hemlet",
    "tags": [
      "история",
      "игры"
    ]
  },
  {
    "slug": "wall_picture",
    "tags": [
      "творчество",
      "интерьер"
    ]
  },
  {
    "slug": "way_signs",
    "tags": [
      "навигация",
      "транспорт"
    ]
  },
  {
    "slug": "woman_stands",
    "tags": [
      "люди"
    ]
  },
  {
    "slug": "wrench_tool",
    "tags": [
      "инструменты",
      "ремонт"
    ]
  }
];

export const searchIcons = (query) => {
  if (!query) return ICONS_DB;
  const q = query.toLowerCase();
  return ICONS_DB.filter(i =>
    i.slug.includes(q) || i.tags.some(t => t.includes(q))
  );
};
