// Универсальный компонент иконки через CSS mask-image
// Цвет меняется через color проп или CSS currentColor
// SVG файлы лежат в public/icons/

export const BudIcon = ({ slug, size = 24, color = 'currentColor', style, ...props }) => (
  <span
    style={{
      display:       'inline-block',
      width:         size,
      height:        size,
      flexShrink:    0,
      backgroundColor: color === 'currentColor' ? 'currentColor' : color,
      maskImage:     `url(/icons/${slug}.svg)`,
      maskSize:      'contain',
      maskRepeat:    'no-repeat',
      maskPosition:  'center',
      WebkitMaskImage:    `url(/icons/${slug}.svg)`,
      WebkitMaskSize:     'contain',
      WebkitMaskRepeat:   'no-repeat',
      WebkitMaskPosition: 'center',
      ...style,
    }}
    {...props}
  />
);
